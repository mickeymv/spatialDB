#include "spatialoperations.h"

		 Point2D getSpatialIntersection(Point2D point1, Point2D point2) {
			 Point2D point;
			 //implementation
			 return point;
		 }
		 Point2D getSpatialUnion(Point2D point1, Point2D point2) {
			 Point2D point;
			 //implementation
			 return point;
		 }
		 Point2D getSpatialDifference(Point2D point1, Point2D point2) {
			 Point2D point;
			 //implementation
			 return point;
		 }
		 Line2D getSpatialIntersection(Line2D line1, Line2D line2) {
			 Line2D line;
			 //implementation
			 return line;
		 }
		 Line2D getSpatialUnion(Line2D line1, Line2D line2) {
			 Line2D line;
			 //implementation
			 return line;
		 }
		 Line2D getSpatialDifference(Line2D line1, Line2D line2) {
			 Line2D line;
			 //implementation
			 return line;
		 }
		 Region2D getSpatialIntersection(Region2D region1, Region2D region2) {
			 Region2D region;
			 //implementation
			 return region;
		 }
		 Region2D getSpatialUnion(Region2D region1, Region2D region2) {
			 Region2D region;
			 //implementation
			 return region;
		 }
		 Region2D getSpatialDifference(Region2D region1, Region2D region2) {
			 Region2D region;
			 //implementation
			 return region;
		 }

